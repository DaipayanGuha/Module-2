function validateLoginForm(){
	if(loginForm.associateId.values==""){
		alert("Enter Associate ID.");
		return false;
	}
	else if(loginForm.password.value==""){
		alert("Enter Password");
		return false;
	}
}

function validateRegistrationForm(){
	if(registerForm.firstName.values==""){
		alert("Enter First Name");
		return false;
	}
	else if(registerForm.lastName.value==""){
		alert("Enter Last Name");
		return false;
	}
	else if(registerForm.emailId.value==""){
		alert("Enter Email ID.");
		return false;
	}
	else if(registerForm.department.value==""){
		alert("Enter Department");
		return false;
	}
	else if(registerForm.designation.value==""){
		alert("Enter Designation");
		return false;
	}
	else if(registerForm.pancardNo.value==""){
		alert("Enter Pancard Number");
		return false;
	}
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
		alert("Enter yearly Investment");
		return false;
	}
	else if(registerForm.basicSalary.value==""){
		alert("Enter Basic Salary");
		return false;
	}else if(registerForm.accountNo.value==""){
		alert("Enter Account Number");
		return false;
	}else if(registerForm.bankName.value==""){
		alert("Enter Bank Name");
		return false;
	}else if(registerForm.ifscCode.value==""){
		alert("Enter IFSC Code");
		return false;
	}
	
}

function validatePassword(){
	if(changePasswordForm.password.value.length>=6){
		if(changePasswordForm.password.value.search(/[0-9]/)!=-1 &&
				changePasswordForm.password.value.search(/[A-Z]/)!=-1 &&
				changePasswordForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("Password must contain atleast 1 number 1 uppcase letter and 1 special character");
			return false;
		}
	}
	else{
		alert("Length must be of Minimum 6 characters");
		return false;
	}
}
	
	function checkSame(){
		if(changePasswordForm.password.value != changePasswordForm.confirmPassword.value){
			alert("Password and confirm password do not match");
			return false;
		}
	}