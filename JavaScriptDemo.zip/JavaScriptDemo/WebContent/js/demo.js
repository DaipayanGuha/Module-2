function sayHello1(){
	document.getElementById("msg").innerHTML="<font color='red'>Hello World in Browser"
	console.log("Hello World on console")
}

function sayHello2() {
	alert("This is an alert box")
}
